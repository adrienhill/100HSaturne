package hei.projet.services;

import java.util.List;

import hei.projet.dao.impl.PublicationDaoImpl;
import hei.projet.entities.Publication;

public class PublicationService {

	private PublicationDaoImpl publicationDao = new PublicationDaoImpl();
	
	private static class PublicationServiceHolder{
		private static PublicationService instance = new PublicationService();
	}
	
	public static PublicationService getInstance(){
		return PublicationServiceHolder.instance;
	}
	
	private PublicationService(){
		
	}

	public List<Publication> listPublication(){
		return publicationDao.listPublications();
	}
	
	public Publication getPublication(Integer id){
		return publicationDao.getPublication(id);
	}
	
	public void addPublication(Publication publication){
		publicationDao.addPublication(publication);
	}
	
	public void removePublication(Integer id){
		publicationDao.removePublication(id);
	}
}
