package hei.projet.dao;

import hei.projet.entities.Video;

public interface VideoDao {

	public void addVideo (Video video);
}
