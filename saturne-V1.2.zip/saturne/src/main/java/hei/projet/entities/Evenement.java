package hei.projet.entities;

import java.time.LocalDateTime;

public class Evenement {
	
	private Integer idEvenement;
	private String titleEvenement;
	private String lieuEvenement;
	private LocalDateTime heureDebutEvenement;
	private LocalDateTime heureFinEvenement;
	private Categorie categorie;
	private Etudiant etudiant;
	
	public Evenement(Integer idEvenement, String titleEvenement, 
			String lieuEvenement, LocalDateTime heureDebutEvenement,
			LocalDateTime heureFinEvenement, Categorie categorie,
			Etudiant etudiant){		
	super();
	this.idEvenement = idEvenement;
	this.titleEvenement = titleEvenement;
	this.lieuEvenement = lieuEvenement;
	this.heureDebutEvenement = heureDebutEvenement;
	this.heureFinEvenement = heureFinEvenement;
	this.categorie = categorie;
	this.etudiant = etudiant; 
	}

	public Integer getIdEvenement() {
		return idEvenement;
	}

	public void setIdEvenement(Integer idEvenement) {
		this.idEvenement = idEvenement;
	}

	public String getTitleEvenement() {
		return titleEvenement;
	}

	public void setTitleEvenement(String titleEvenement) {
		this.titleEvenement = titleEvenement;
	}

	public String getLieuEvenement() {
		return lieuEvenement;
	}

	public void setLieuEvenement(String lieuEvenement) {
		this.lieuEvenement = lieuEvenement;
	}

	public LocalDateTime getHeureDebutEvenement() {
		return heureDebutEvenement;
	}

	public void setHeureDebutEvenement(LocalDateTime heureDebutEvenement) {
		this.heureDebutEvenement = heureDebutEvenement;
	}

	public LocalDateTime getHeureFinEvenement() {
		return heureFinEvenement;
	}

	public void setHeureFinEvenement(LocalDateTime heureFinEvenement) {
		this.heureFinEvenement = heureFinEvenement;
	}

	public Categorie getCategorie() {
		return categorie;
	}

	public void setCategorie(Categorie categorie) {
		this.categorie = categorie;
	}

	public Etudiant getEtudiant() {
		return etudiant;
	}

	public void setEtudiant(Etudiant etudiant) {
		this.etudiant = etudiant;
	}
	
	
}
