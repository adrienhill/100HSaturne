package hei.projet.pojos;

public class Categorie {

		private Integer idCategorie;
		private String titrePublication;
		
		
		
		public Categorie(Integer idCategorie, String titrePublication) {
			super();
			this.idCategorie = idCategorie;
			this.titrePublication = titrePublication;
		}
		public Integer getIdCategorie() {
			return idCategorie;
		}
		public void setIdCategorie(Integer idCategorie) {
			this.idCategorie = idCategorie;
		}
		public String getTitrePublication() {
			return titrePublication;
		}
		public void setTitrePublication(String titrePublication) {
			this.titrePublication = titrePublication;
		}
		
		
		
		
		
	

}
