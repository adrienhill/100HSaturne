package hei.projet.pojos;

public class Etudiant {

	private Integer idEtudiant;
	private String mailEtudiant;
	private String mdpEtudiant;
	
	
	
	
	public Etudiant(Integer idEtudiant, String mailEtudiant, String mdpEtudiant, Boolean administrateur) {
		super();
		this.idEtudiant = idEtudiant;
		this.mailEtudiant = mailEtudiant;
		this.mdpEtudiant = mdpEtudiant;
		
	}
	public Integer getIdEtudiant() {
		return idEtudiant;
	}
	public void setIdEtudiant(Integer idEtudiant) {
		this.idEtudiant = idEtudiant;
	}
	public String getMailEtudiant() {
		return mailEtudiant;
	}
	public void setMailEtudiant(String mailEtudiant) {
		this.mailEtudiant = mailEtudiant;
	}
	public String getMdpEtudiant() {
		return mdpEtudiant;
	}
	public void setMdpEtudiant(String mdpEtudiant) {
		this.mdpEtudiant = mdpEtudiant;
	}


}
