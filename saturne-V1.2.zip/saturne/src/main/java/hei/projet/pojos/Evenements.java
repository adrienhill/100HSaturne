package hei.projet.pojos;

import java.time.LocalDate;

public class Evenements {

	private Integer idEvenement;
	private String titreEvenement;
	private String lieuEvenement;
	private LocalDate datedebutEvenement;
	private LocalDate datefinEvenement;
	
	
	
	public Evenements(Integer idEvenement, String titreEvenement, String lieuEvenement, LocalDate datedebutEvenement,
			LocalDate datefinEvenement) {
		super();
		this.idEvenement = idEvenement;
		this.titreEvenement = titreEvenement;
		this.lieuEvenement = lieuEvenement;
		this.datedebutEvenement = datedebutEvenement;
		this.datefinEvenement = datefinEvenement;
	}
	public Integer getIdEvenement() {
		return idEvenement;
	}
	public void setIdEvenement(Integer idEvenement) {
		this.idEvenement = idEvenement;
	}
	public String getTitreEvenement() {
		return titreEvenement;
	}
	public void setTitreEvenement(String titreEvenement) {
		this.titreEvenement = titreEvenement;
	}
	public String getLieuEvenement() {
		return lieuEvenement;
	}
	public void setLieuEvenement(String lieuEvenement) {
		this.lieuEvenement = lieuEvenement;
	}
	public LocalDate getDatedebutEvenement() {
		return datedebutEvenement;
	}
	public void setDatedebutEvenement(LocalDate datedebutEvenement) {
		this.datedebutEvenement = datedebutEvenement;
	}
	public LocalDate getDatefinEvenement() {
		return datefinEvenement;
	}
	public void setDatefinEvenement(LocalDate datefinEvenement) {
		this.datefinEvenement = datefinEvenement;
	}
	

}
