package hei.projet.pojos;

import java.time.LocalDate;

public class Video {


	private Integer idVideo;
	private String titreVideo;
	private LocalDate dateVideo;
	
	
	
	
	
	public Video(Integer idVideo, String titreVideo, LocalDate dateVideo) {
		super();
		this.idVideo = idVideo;
		this.titreVideo = titreVideo;
		this.dateVideo = dateVideo;
	}
	public Integer getIdVideo() {
		return idVideo;
	}
	public void setIdVideo(Integer idVideo) {
		this.idVideo = idVideo;
	}
	public String getTitreVideo() {
		return titreVideo;
	}
	public void setTitreVideo(String titreVideo) {
		this.titreVideo = titreVideo;
	}
	public LocalDate getDateVideo() {
		return dateVideo;
	}
	public void setDateVideo(LocalDate dateVideo) {
		this.dateVideo = dateVideo;
	}
	
	
		
	

}
