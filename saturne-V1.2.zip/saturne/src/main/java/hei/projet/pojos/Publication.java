package hei.projet.pojos;

import java.time.LocalDate;

public class Publication {

	private Integer idPublication;
	private String titrePublication;
	private LocalDate datePublication;
	private String lienPublication;
	
	
	
	
	
	public Publication(Integer idPublication, String titrePublication, LocalDate datePublication,
			String lienPublication) {
		super();
		this.idPublication = idPublication;
		this.titrePublication = titrePublication;
		this.datePublication = datePublication;
		this.lienPublication = lienPublication;
	}
	public Integer getIdPublication() {
		return idPublication;
	}
	public void setIdPublication(Integer idPublication) {
		this.idPublication = idPublication;
	}
	public String getTitrePublication() {
		return titrePublication;
	}
	public void setTitrePublication(String titrePublication) {
		this.titrePublication = titrePublication;
	}
	public LocalDate getDatePublication() {
		return datePublication;
	}
	public void setDatePublication(LocalDate datePublication) {
		this.datePublication = datePublication;
	}
	public String getLienPublication() {
		return lienPublication;
	}
	public void setLienPublication(String lienPublication) {
		this.lienPublication = lienPublication;
	}
	

}
