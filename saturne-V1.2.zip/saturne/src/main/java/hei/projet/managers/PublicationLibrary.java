package hei.projet.managers;
/*
import java.util.List;

import hei.projet.dao.CategorieDao;
import hei.projet.dao.impl.CategorieDaoImpl;
import hei.projet.entities.Categorie;



public class PublicationLibrary {
	
	private static class PublicationLibraryHolder {
		private final static PublicationLibrary instance = new PublicationLibrary();
	}
	
	public static PublicationLibrary getInstance() {
		return PublicationLibraryHolder.instance;
	}
	
	private PublicationDao publicationDao = new PublicationDaoImpl();
	private CategorieDao categorieDao = new CategorieDaoImpl();	

	private PublicationLibrary() {
	}

	public List<Publication> listPublications() {
		return publicationDao.listPublications();
	}

	public Publication getPublication(Integer id) {
		return publicationDao.getPublication(id);
	}

	public Publication addPublication(Publication publication) {
		return publicationDao.addFilm(publication);
	}

	public List<Categorie> listCategories() {
		return categorieDao.listCategories();
	}

	public Categorie getCategorie(Integer id) {
		return categorieDao.getCategorie(id);
	}

	public Categorie addCategorie(String nom) {
		return categorieDao.addCategorie(nom);
	}

}
*/