package hei.projet.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import hei.projet.dao.EvenementDao;
import hei.projet.entities.Categorie;
import hei.projet.entities.Evenement;
import oenologHei.daos.DataSourceProvider;

public class EvenementDaoImpl implements EvenementDao {

	@Override
	public List<Evenement> listEvenements() {
		String query = "SELECT * FROM evenement ORDER BY idEvenement";
		List<Evenement> evenements = new ArrayList<>(); 
		try (Connection connection = DataSourceProvider.getDataSource().getConnection()) {
			try (Statement statement = connection.createStatement()) {
				try (ResultSet resultSet = statement.executeQuery(query)) {
					while(resultSet.next()) {
						Evenement evenement = new Evenement(resultSet.getInt("idEvenement"), resultSet.getString("titleEvenement"), resultSet.getString("lieuEvenement"),resultSet.getDate("heureDebutEvenement"), resultSet.getDate("heureFinEvenement"),resultSet.getCategorie("categorie"),resultSet.getEtudiant("etudiant"));
						evenements.add(evenement);
					}
				}
			}			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return evenements;
	}

	@Override
	public Evenement getEvenement(Integer id) {
		try (Connection connection = DataSourceProvider.getDataSource().getConnection()) {
			try(PreparedStatement statement = connection.prepareStatement("SELECT * FROM evenement WHERE idEvenement = ?")) {
				statement.setInt(1, id);
				try (ResultSet resultSet = statement.executeQuery()) {
					if(resultSet.next()) {
						return new Evenement(resultSet.getInt("idEvenement"), resultSet.getString("titleEvenement"), resultSet.getString("lieuEvenement"), resultSet.getDate("heureDebutEvenement"), resultSet.getDate("heureFinEvenement"), resultSet.getCategorie("categorie"), resultSet.getEtudiant("etudiant");// Remplacer les getCategorie et getEtudiant					}
				}
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Evenement addEvenement(Evenement evenement) {
		try(Connection connection = DataSourceProvider.getDataSource().getConnection();
				PreparedStatement statement = connection.prepareStatement("INSERT INTO Evenement(idEvenement,titleEvenement, lieuEvenement, heureDebutEvenement, heureFinEvenement, categorie, etudiant) VALUES(?,?,?,?,?,?,?)")
						){
			statement.setInt(1, evenement.getIdEvenement());
			statement.setString(2, evenement.getTitleEvenement());
			statement.setString(3, evenement.getLieuEvenement());
			statement.setString(4, evenement.getLieuEvenement());
			statement.setDate(5, evenement.getHeureDebutEvenement());
			statement.setDate(6, evenement.getHeureFinEvenement());
			statement.SetCategorie(7, evenement.getCategorie());
			statement.SetEtudiant(8, evenement.setEtudiant(etudiant));
			statement.executeUpdate();
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void removeEvenement(Integer idEvenement){
		try(Connection connection = DataSourceProvider.getDataSource().getConnection();
				PreparedStatement statement = connection.prepareStatement("DELETE FROM evenement WHERE idEvenement=?")
						){
			statement.setInt(1,idEvenement);
			statement.executeUpdate();
			
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		}

	

}
