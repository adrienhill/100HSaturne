package hei.projet.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import hei.projet.dao.EtudiantDao;
import hei.projet.entities.Etudiant;
import oenologHei.daos.DataSourceProvider;


public class EtudiantDaoImpl implements EtudiantDao {

	@Override
	public List<Etudiant> listEtudiants() {
		String query = "SELECT * FROM etudiant";
		List<Etudiant> etudiants = new ArrayList<>(); 
		try (Connection connection = DataSourceProvider.getDataSource().getConnection()) {
			try (Statement statement = connection.createStatement()) {
				try (ResultSet resultSet = statement.executeQuery(query)) {
					while(resultSet.next()) {
						Etudiant etudiant = new Etudiant(resultSet.getInt("id"), resultSet.getString("email"), resultSet.getString("motDePasse"));
						etudiants.add(etudiant);
					}
				}
			}			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return etudiants;
		
	}

	@Override
	public Etudiant getEtudiant(Integer id) {
		try (Connection connection = DataSourceProvider.getDataSource().getConnection()) {
			try(PreparedStatement statement = connection.prepareStatement("SELECT * FROM categorie WHERE idEtudiant = ?")) {
				statement.setInt(1, id);
				try (ResultSet resultSet = statement.executeQuery()) {
					if(resultSet.next()) {
						return  new Etudiant(resultSet.getInt("id"), resultSet.getString("email"), resultSet.getString("motDePasse"));
					}
				}
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public void addEtudiant(Etudiant etudiant) {
		try(Connection connection = DataSourceProvider.getDataSource().getConnection();
				PreparedStatement statement = connection.prepareStatement("INSERT INTO Etudiant(id, email,motDPasse) VALUES(?,?,?)")
						){
			statement.setInt(1,etudiant.getId());
			statement.setString(2,etudiant.getEmail());
			statement.setString(3, etudiant.getMotDePasse());
			statement.executeUpdate();
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void removeEtudiant(Integer id){
	try(Connection connection = DataSourceProvider.getDataSource().getConnection();
			PreparedStatement statement = connection.prepareStatement("DELETE FROM etudiant WHERE id=?")
					){
		statement.setInt(1,id);
		statement.executeUpdate();
		
	}catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		
	}
}

	


