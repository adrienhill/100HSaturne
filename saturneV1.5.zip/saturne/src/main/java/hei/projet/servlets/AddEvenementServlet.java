package hei.projet.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import hei.projet.entities.Evenement;
import hei.projet.services.EvenementService;

@WebServlet("/priveAdmin/addEvenement")
public class AddEvenementServlet extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String titleEvenement = req.getParameter("titre");
		String lieuEvenement = req.getParameter("lieu");
		// Categorie categorieEvenement = req.getParameter("categorie");
		String heureDebutEvenemenetAsString = req.getParameter("date");
		// Attention erreur, il y a une deuxieme date (Inspecter forme data)
		
		Evenement evenementToAdd = new Evenement(null, titleEvenement, lieuEvenement, heureDebutEvenement, heureFinEvenement, categorie);
		EvenementService.getInstance().addEvenement(evenementToAdd);
		
		
		
	}
	
	
}
